<?php    
   include "conexion.php";
 // usuario esta lo pasa a la pagina de acceso y si no lo encuentra 
//   mosi elstrara un mensaje  o lo puede enviar a alguna pagina que ustedes hagan 

   $login_nombre_completo  = $_POST["nombre_completo"];
   $login_contraseña = $_POST["contraseña"];

   $sql    = "select * from tabla_registro where nombre_completo= '$login_nombre_completo' and contraseña = '$login_contraseña'  ";
   $result = $base_de_datos->query($sql);


   $filas =mysqli_fetch_array($result);

   if ($filas["id_usuario"]==1) {
      header('Location: /PROYECTO PEWOQ/phplogin/listarPersonas.php ');    
   } else if($result->num_rows > 0) {
      header('Location: /PROYECTO PEWOQ/index.html ');
   } else  {
      header('Location: ../phplogin/popup2.html ');
   }


  // header('Location: RegistarPersona.html?user='.$login_usuario);
?>

