<?php

   if(!isset($_GET["id"])) exit();
  
    $id = $_GET["id"];
  
	include_once "../conexion.php";
	
	$sentencia = $base_de_datos->prepare("DELETE FROM tabla_registro WHERE id = ?;");
	$resultado = $sentencia->execute([$id]);
	
	if($resultado === TRUE) 
	   echo "Eliminado correctamente!<br>";
	else 
	  echo "No fue posible eliminar el registro <br>";
	
	echo" <a href='../listarPersonas.php'>Atras</a>";
?>
