<?php

include ("../conexion.php");

$nombre_completo    = $_POST["nombre_completo"];
$email              = $_POST["email"];
$telefono           = $_POST["telefono"];
$contraseña         = $_POST["contraseña"];
$id                 = $_POST["id"];


$sentencia = $base_de_datos->prepare("UPDATE `tabla_registro` SET nombre_completo = '$nombre_completo', 
`email` = '$email', `telefono` = '$telefono', `contraseña = $contraseña WHERE `id` = '$id'");


if($resultado == TRUE)
  header('Location: ../listarPersonas.php '); 

	
?>