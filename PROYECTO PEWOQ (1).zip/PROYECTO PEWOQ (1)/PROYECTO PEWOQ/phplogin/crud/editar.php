<?php
  if(!isset($_GET["id"])) exit();
  
  include("../conexion.php");
  $id = $_GET["id"];
  $sentencia = "SELECT * FROM tabla_registro WHERE id =".$id;
  $result = mysqli_query($base_de_datos, $sentencia);
  while($persona = mysqli_fetch_assoc($result)){;
?> 
<!doctype html>
<html lang="es">
<head>
  <title>LOGIN PEWOQ</title>
  <meta charset="utf-8">
  <link rel="icon" type="image/x-icon" href="/PROYECTO PEWOQ/assets/img/WhatsApp Image 2023-12-13 at 12.49.46 AM.ico" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="/PROYECTO PEWOQ/phplogin/styleslogin.css">
</head>
<body>
<div id="stars"></div>
<div id="stars2"></div>
<div id="stars3"></div>
<div class="section">
  <div class="container">
    <div class="row full-height justify-content-center">
      <div class="col-12 text-center align-self-center py-5">
        <div class="section pb-5 pt-5 pt-sm-2 text-center">
                <div class="section text-center">
                <h6 class="mb-0 pb-3"><span>EDITAR USUARIO</span></h6>
                        <form action="/PROYECTO PEWOQ/phplogin/crud/guardarDatosEditados.php" method="POST">
                            <div class="form-group">
                                <input value="<?php echo $persona["nombre_completo"]?>" name="nombre_completo" id="nombre_completo" required type="text" class="form-style" placeholder="Nombre Completo">
                                    <i class="input-icon uil uil-user"></i>
                            </div>	
                            <div class="form-group mt-2">
                                <input value="<?php echo $persona["email"]; ?>" name="email" id="email" required type="email" class="form-style" placeholder="Correo">
                                    <i class="input-icon uil uil-at"></i>
                            </div>	
                            <div class="form-group mt-2">
                                <input value="<?php echo $persona["telefono"]; ?>" name="telefono" id="telefono" required type="text" class="form-style" placeholder="Telefono">
                                    <i class="input-icon uil uil-phone"></i>
                            </div>
                            <div class="form-group mt-2">
                                <input value="<?php echo $persona["contraseña"]; ?>" name="contraseña" id="contraseña" required type="password" class="form-style" placeholder="Contraseña">
                                    <i class="input-icon uil uil-lock-alt"></i>
                            </div>
                            
                            <?php
                            }
                            ?>
                            <input name="submit" value="Editar Cambios" type="submit" class="btn mt-4"></input>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
</body>
</html>