<?php

#Salir si alguno de los datos no está presente
if(
	!isset($_POST["nombre_completo"]) || 
	!isset($_POST["email"]) || 
	!isset($_POST["telefono"]) || 
	!isset($_POST["contraseña"]) || 
	!isset($_POST["id"])
) exit();

#Si todo va bien, se ejecuta esta parte del código...

include_once "conexion.php";
$id = $_POST["id"];
$usuario    = $_POST["nombre_completo"];
$correito   = $_POST["email"];
$numero     = $_POST["telefono"];
$password   = $_POST["contraseña"];

$sentencia = $base_de_datos->prepare("UPDATE personas SET nombre_completo = ?, email = ?, telefono = ?, contraseña = ?, WHERE id = ?;");
$resultado = $sentencia->execute([$usuario, $correito, $numero, $password, $id]); # Pasar en el mismo orden de los ?
if($resultado === TRUE)
   echo "Cambios guardados";
else 
	echo "Algo salió mal. Por favor verifica que la tabla exista, así como el ID del usuario";


	echo" <br><a href='../listarPersonas.php'>Atras</a>";
	
?>