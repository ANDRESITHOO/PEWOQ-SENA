<?php
  if(!isset($_GET["id"])) exit();
  
  $id = $_GET["id"];
  include_once "../conexion.php";
  $sentencia = $base_de_datos->query("SELECT * FROM personas WHERE id =".$id);
  $persona = $sentencia->fetch_assoc() ;
?> 
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles.css">

</head>
<body>
    <form method="post" action="RegistarPersona.php"></form>
        <div class="form-group">
            <input value="<?php echo $persona["nombre_completo"]?>" name="nombre_completo" id="nombre_completo" required type="text" class="form-style" placeholder="Nombre Completo">
                <i class="input-icon uil uil-user"></i>
        </div>	
        <div class="form-group mt-2">
            <input value="<?php echo $persona["email"]; ?>" name="email" id="email" required type="email" class="form-style" placeholder="Correo">
                <i class="input-icon uil uil-at"></i>
        </div>	
        <div class="form-group mt-2">
            <input value="<?php echo $persona["telefono"]; ?>" name="telefono" id="telefono" required type="tel" class="form-style" placeholder="Telefono">
                <i class="input-icon uil uil-phone"></i>
        </div>
        <div class="form-group mt-2">
            <input value="<?php echo $persona["contraseña"]; ?>" name="contraseña" id="contraseña" required type="password" class="form-style" placeholder="Contraseña">
                <i class="input-icon uil uil-lock-alt"></i>
        </div>
            <a type="submit" value ="Editar Cambios" class="btn mt-4">Aceptar</a>
    </form>
</body>
</html>